<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="map2" tilewidth="30" tileheight="30" tilecount="1160" columns="40">
 <image source="Map2.png" width="1200" height="896"/>
</tileset>
