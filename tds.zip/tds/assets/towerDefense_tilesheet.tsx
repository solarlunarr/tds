<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="towerDefense_tilesheet" tilewidth="30" tileheight="30" tilecount="1323" columns="49">
 <image source="kenney_tower-defense-top-down/Tilesheet/towerDefense_tilesheet.png" width="1472" height="832"/>
</tileset>
