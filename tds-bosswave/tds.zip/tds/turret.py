import pygame as pg
import Constants as c
import math
from turret_data import TURRET_DATA
from bullet import Bullet

class Turret(pg.sprite.Sprite):
    def __init__(self, image, tile_x, tile_y):
        pg.sprite.Sprite.__init__(self)
        self.upgrade_level = 1
        self.range = TURRET_DATA[self.upgrade_level - 1].get("range")
        self.cooldown = TURRET_DATA[self.upgrade_level - 1].get("cooldown")
        self.dmg = TURRET_DATA[self.upgrade_level - 1].get("damage")
        self.last_shot = pg.time.get_ticks()
        self.selected = False
        self.target = None
        self.original_image = pg.image.load("tds/assets/IceTurret.png")
        #position variables ------------------------------------------
        self.tile_x = tile_x
        self.tile_y = tile_y
        #calculate center coordinates --------------------------------
        self.x = (self.tile_x + 0.5) * c.TILE_SIZE
        self.y = (self.tile_y + 0.5 ) * c.TILE_SIZE

        #update image
        self.angle = 90
        self.image = pg.transform.rotate(self.original_image, self.angle)
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)

        #create transparent circle showing range
        self.range_image = pg.Surface((self.range * 2, self.range * 2))
        self.range_image.fill((0, 0, 0))
        self.range_image.set_colorkey((0, 0, 0))
        pg.draw.circle(self.range_image, "grey100", (self.range, self.range), self.range)
        self.range_image.set_alpha(100)
        self.range_rect = self.range_image.get_rect()
        self.range_rect.center = self.rect.center

    def draw(self, surface):
        self.image = pg.transform.rotate(self.original_image, self.angle - 90)
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        surface.blit(self.image, self.rect)
        if self.selected:
            surface.blit(self.range_image, self.range_rect)

    def update(self, enemy_group, world, bullet_image, bullet_group):
        if pg.time.get_ticks() - self.last_shot > (self.cooldown / world.game_speed):
            self.pick_target(enemy_group, bullet_image, bullet_group)


    def pick_target(self, enemy_group, bullet_image, bullet_group):
      #find an enemy to target
        x_dist = 0
        y_dist = 0
     #check distance to each enemy to see if it is in range
        for enemy in enemy_group:
            if enemy.health > 0:
                x_dist = enemy.pos[0] - self.x
                y_dist = enemy.pos[1] - self.y
                dist = math.sqrt(x_dist ** 2 + y_dist ** 2)
                if dist < self.range:
                    self.target = enemy
                    self.angle = math.degrees(math.atan2(-y_dist, x_dist))
                    #spawn bullet
                    new_bullet = Bullet(bullet_image, self.x, self.y, self.target.pos, self.dmg)
                    bullet_group.add(new_bullet)
                    self.last_shot = pg.time.get_ticks()
                    break

    def upgrade(self):
        self.upgrade_level +=1
        self.range = TURRET_DATA[self.upgrade_level - 1].get("range")
        self.cooldown = TURRET_DATA[self.upgrade_level - 1].get("cooldown")
        self.dmg = TURRET_DATA[self.upgrade_level - 1].get("damage")
        #draw new transparent circle showing range
        self.range_image = pg.Surface((self.range * 2, self.range * 2))
        self.range_image.fill((0, 0, 0))
        self.range_image.set_colorkey((0, 0, 0))
        pg.draw.circle(self.range_image, "grey100", (self.range, self.range), self.range)
        self.range_image.set_alpha(100)
        self.range_rect = self.range_image.get_rect()
        self.range_rect.center = self.rect.center
    
    # def apply_math(self, operator):
    #     if operator == '+':
    #         self.damage += 5
    #     elif operator == '-':
    #         # Reduces cooldown delay (attacks faster)
    #         self.cooldown = max(100, self.cooldown - 200) 
    #     elif operator == 'x':
    #         self.damage = int(self.damage * 1.5)
    #     elif operator == '/':
    #         self.cooldown = max(100, int(self.cooldown * 0.7)) # 30% faster fire rate
    #     elif operator == '^':
    #         self.damage = self.damage ** 2
    #     print(f"Turret Upgraded! Damage: {self.damage}, Cooldown: {self.cooldown}ms"
