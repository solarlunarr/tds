<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="towerDefense_tilesheet@2" tilewidth="30" tileheight="30" tilecount="5390" columns="98">
 <image source="kenney_tower-defense-top-down/Tilesheet/towerDefense_tilesheet@2.png" width="2944" height="1664"/>
 <tile id="99">
  <objectgroup draworder="index" id="2">
   <object id="1" x="14.8202" y="15.0703"/>
   <object id="2" x="-0.625326" y="-3.00156"/>
  </objectgroup>
 </tile>
</tileset>
